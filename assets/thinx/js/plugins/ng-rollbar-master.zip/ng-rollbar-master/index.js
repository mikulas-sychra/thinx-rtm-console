require('./ng-rollbar.js');
module.exports = 'tandibar/ng-rollbar';
